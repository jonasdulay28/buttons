<?php
if(file_exists("config.php")){
	echo "it's aleady installed!";
}
else{
	header("Location: setup.php");
}
?>