<?php
####################################
#  autoload.php
#
#  Author: Shashwat shagun
#  email : shashwat@iamshashwat.in
#  date  : 19/06/2016
####################################

    require_once('class.phpmailer.php');
    require_once 'config.php';
    /**
    * PHP2SMTP
    */
     $conf = new CONFIGURATION;
    class php2smtp extends CONFIGURATION
    {
    //$from=$conf->email,$fromName=$conf->name,$replyto=$conf->replyto,$replyname=$conf->replyname,

   public function send($to,$subject,$message,$name)
    {
      echo "hello"."<br/>";
                  $mail             = new PHPMailer();
                  $body             = $message;
                  $mail->IsSMTP();
                  $mail->SMTPAuth   = true;
                  $mail->Host       = "mail.iamshashwat.in";
                  $mail->Port       = 26;
                  $mail->Username   = "shashwat@iamshashwat.in";
                  $mail->Password   = "ranjan12345";
                  //$mail->SMTPSecure = 'tls';
                  $mail->SetFrom($this->email,$this->name);
                  $mail->AddReplyTo($this->replyto,$this->replyname);
                  $mail->Subject    = $subject;
                  $mail->AltBody    = "message.";
                  $mail->MsgHTML($body);
                  $address = $to;
                  $mail->AddAddress($address, $name);
                  if(!$mail->Send()) {
                      return false;
                  } else {
                      return true;
                 }
    }}
?>
